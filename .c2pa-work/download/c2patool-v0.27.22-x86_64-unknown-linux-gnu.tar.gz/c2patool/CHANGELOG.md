# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.27.22](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.21...c2patool-v0.27.22)
_10 September 2026_

## [0.27.21](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.20...c2patool-v0.27.21)
_09 September 2026_

## [0.27.20](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.19...c2patool-v0.27.20)
_04 September 2026_

## [0.27.19](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.18...c2patool-v0.27.19)
_04 September 2026_

## [0.27.18](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.17...c2patool-v0.27.18)
_04 September 2026_

## [0.27.17](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.16...c2patool-v0.27.17)
_03 September 2026_

## [0.27.16](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.15...c2patool-v0.27.16)
_27 August 2026_

## [0.27.15](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.14...c2patool-v0.27.15)
_13 August 2026_

## [0.27.14](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.13...c2patool-v0.27.14)
_13 August 2026_

## [0.27.13](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.12...c2patool-v0.27.13)
_13 August 2026_

## [0.27.12](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.11...c2patool-v0.27.12)
_12 August 2026_

## [0.27.11](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.10...c2patool-v0.27.11)
_12 August 2026_

## [0.27.10](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.9...c2patool-v0.27.10)
_10 August 2026_

## [0.27.9](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.8...c2patool-v0.27.9)
_10 August 2026_

## [0.27.8](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.7...c2patool-v0.27.8)
_07 August 2026_

## [0.27.7](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.6...c2patool-v0.27.7)
_07 August 2026_

## [0.27.6](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.5...c2patool-v0.27.6)
_06 August 2026_

## [0.27.5](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.4...c2patool-v0.27.5)
_05 August 2026_

## [0.27.4](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.3...c2patool-v0.27.4)
_04 August 2026_

## [0.27.3](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.2...c2patool-v0.27.3)
_24 July 2026_

## [0.27.2](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.1...c2patool-v0.27.2)
_23 July 2026_

## [0.27.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.27.0...c2patool-v0.27.1)
_21 July 2026_

## [0.27.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.72...c2patool-v0.27.0)
_16 July 2026_

### Changed

* Transition release onto the new scheduled breaking-change release train (see [release process](https://github.com/contentauth/c2pa-rs/blob/main/docs/release-process.md)). This is a version-only bump: there are no `c2patool` code changes since 0.26.72 ([#2250](https://github.com/contentauth/c2pa-rs/pull/2250)).

## [0.26.72](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.71...c2patool-v0.26.72)
_13 July 2026_

## [0.26.71](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.70...c2patool-v0.26.71)
_13 July 2026_

## [0.26.70](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.69...c2patool-v0.26.70)
_09 July 2026_

### Fixed

* Fix new Clippy warnings for Rust 1.97.0 ([#2279](https://github.com/contentauth/c2pa-rs/pull/2279))
* Ensure created has a dst and don't add parent when actions already exist ([#2264](https://github.com/contentauth/c2pa-rs/pull/2264))

## [0.26.69](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.68...c2patool-v0.26.69)
_07 July 2026_

## [0.26.68](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.67...c2patool-v0.26.68)
_19 June 2026_

## [0.26.67](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.66...c2patool-v0.26.67)
_11 June 2026_

### Added

* Remove some long deprecated APIs ([#2206](https://github.com/contentauth/c2pa-rs/pull/2206))

## [0.26.66](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.65...c2patool-v0.26.66)
_11 June 2026_

### Fixed

* Enable c2pa features in sub-crates since default-features is disabled at the workspace-level ([#2219](https://github.com/contentauth/c2pa-rs/pull/2219))

### Other

* Use latest `release-plz` and add a dry run job on release PRs ([#2217](https://github.com/contentauth/c2pa-rs/pull/2217))

## [0.26.65](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.64...c2patool-v0.26.65)
_09 June 2026_

### Fixed

* DLL hijacking vulnerability in c2patool (CAI-8608) ([#2031](https://github.com/contentauth/c2pa-rs/pull/2031))

## [0.26.64](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.63...c2patool-v0.26.64)
_08 June 2026_

## [0.26.63](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.62...c2patool-v0.26.63)
_04 June 2026_

## [0.26.62](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.61...c2patool-v0.26.62)
_03 June 2026_

## [0.26.61](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.60...c2patool-v0.26.61)
_01 June 2026_

## [0.26.60](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.59...c2patool-v0.26.60)
_27 May 2026_

### Added

* Add Intent support to c2patool ([#2171](https://github.com/contentauth/c2pa-rs/pull/2171))
* Support CAWG callback signing via c_ffi ([#2118](https://github.com/contentauth/c2pa-rs/pull/2118))

### Fixed

* Share reqwest HTTP clients ([#2152](https://github.com/contentauth/c2pa-rs/pull/2152))

### Added

* `--create <source-type>` flag to sign an asset as a new original creation with the specified [C2PA digital source type](https://cv.iptc.org/newscodes/digitalsourcetype/) (e.g. `digitalCapture`, `trainedAlgorithmicMedia`). Automatically injects a `c2pa.created` action. Mutually exclusive with `--update` and `--parent`.
* `--update` flag to generate an [update manifest](https://c2pa.org/specifications/specifications/2.1/specs/C2PA_Specification.html#_update_manifests) for non-editorial changes applied to an already-signed asset. Automatically injects a `c2pa.opened` action and sets the source asset as the parent ingredient. The source asset must already contain a C2PA manifest. Mutually exclusive with `--create`.

### Changed

* Default signing behavior now applies **Edit** intent: the source asset is automatically added as a parent ingredient and a `c2pa.opened` action is injected. Previously no intent or parent was set automatically.
* Signature validation after signing is now enabled by default in all builds (previously only in test builds). Use `--no_signing_verify` to skip it.(https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.58...c2patool-v0.26.59)
_12 May 2026_

## [0.26.58](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.57...c2patool-v0.26.58)
_11 May 2026_

## [0.26.57](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.56...c2patool-v0.26.57)
_11 May 2026_

## [0.26.56](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.55...c2patool-v0.26.56)
_04 May 2026_

## [0.26.55](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.54...c2patool-v0.26.55)
_01 May 2026_

## [0.26.54](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.53...c2patool-v0.26.54)
_01 May 2026_

## [0.26.53](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.52...c2patool-v0.26.53)
_29 April 2026_

### Added

* Add `init trust`, trust sidecars, and atomic sidecar writes, plus fixes ([#2093](https://github.com/contentauth/c2pa-rs/pull/2093))

## [0.26.52](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.51...c2patool-v0.26.52)
_28 April 2026_

### Fixed

* `c2pa-c-ffi` UB detected by miri ([#2089](https://github.com/contentauth/c2pa-rs/pull/2089))

## [0.26.51](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.50...c2patool-v0.26.51)
_27 April 2026_

### Documented

* Corrections and clean up ([#2057](https://github.com/contentauth/c2pa-rs/pull/2057))

## [0.26.50](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.49...c2patool-v0.26.50)
_16 April 2026_

### Fixed

* Multi rendition support ([#2058](https://github.com/contentauth/c2pa-rs/pull/2058))

## [0.26.49](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.48...c2patool-v0.26.49)
_15 April 2026_

## [0.26.48](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.47...c2patool-v0.26.48)
_14 April 2026_

## [0.26.47](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.46...c2patool-v0.26.47)
_09 April 2026_

## [0.26.46](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.45...c2patool-v0.26.46)
_08 April 2026_

### Fixed

* Allow any file type to be signed with a sidecar ([#2014](https://github.com/contentauth/c2pa-rs/pull/2014))

## [0.26.45](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.44...c2patool-v0.26.45)
_07 April 2026_

## [0.26.44](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.43...c2patool-v0.26.44)
_03 April 2026_

## [0.26.43](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.42...c2patool-v0.26.43)
_31 March 2026_

## [0.26.42](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.41...c2patool-v0.26.42)
_27 March 2026_

### Fixed

* Updated crJSON Schema ([#1975](https://github.com/contentauth/c2pa-rs/pull/1975))

### Other

* Update x_509.md ([#1942](https://github.com/contentauth/c2pa-rs/pull/1942))

## [0.26.41](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.40...c2patool-v0.26.41)
_23 March 2026_

## [0.26.40](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.39...c2patool-v0.26.40)
_23 March 2026_

### Added

* Add `cr_json()` and `cr_json_value()` to `Reader`; remove separate `CrJsonReader` ([#1919](https://github.com/contentauth/c2pa-rs/pull/1919))

## [0.26.39](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.38...c2patool-v0.26.39)
_16 March 2026_

### Fixed

* Pin `atree` to 0.5.2 ([#1940](https://github.com/contentauth/c2pa-rs/pull/1940))

## [0.26.38](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.37...c2patool-v0.26.38)
_13 March 2026_

## [0.26.37](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.36...c2patool-v0.26.37)
_12 March 2026_

## [0.26.36](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.35...c2patool-v0.26.36)
_12 March 2026_

## [0.26.35](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.34...c2patool-v0.26.35)
_11 March 2026_

## [0.26.34](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.33...c2patool-v0.26.34)
_10 March 2026_

## [0.26.33](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.32...c2patool-v0.26.33)
_04 March 2026_

## [0.26.32](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.31...c2patool-v0.26.32)
_03 March 2026_

## [0.26.31](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.30...c2patool-v0.26.31)
_02 March 2026_

### Updated dependencies

* Bump toml from 0.9.12+spec-1.1.0 to 1.0.2+spec-1.1.0 ([#1883](https://github.com/contentauth/c2pa-rs/pull/1883))

## [0.26.30](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.29...c2patool-v0.26.30)
_23 February 2026_

## [0.26.29](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.28...c2patool-v0.26.29)
_12 February 2026_

## [0.26.28](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.27...c2patool-v0.26.28)
_12 February 2026_

## [0.26.27](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.26...c2patool-v0.26.27)
_09 February 2026_

## [0.26.26](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.25...c2patool-v0.26.26)
_06 February 2026_

## [0.26.25](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.24...c2patool-v0.26.25)
_06 February 2026_

## [0.26.24](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.23...c2patool-v0.26.24)
_03 February 2026_

## [0.26.23](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.22...c2patool-v0.26.23)
_03 February 2026_

## [0.26.22](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.21...c2patool-v0.26.22)
_03 February 2026_

## [0.26.21](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.20...c2patool-v0.26.21)
_02 February 2026_

## [0.26.20](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.19...c2patool-v0.26.20)
_30 January 2026_

## [0.26.19](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.18...c2patool-v0.26.19)
_28 January 2026_

## [0.26.18](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.17...c2patool-v0.26.18)
_27 January 2026_

### Documented

* Remove outdated ref to CreativeWork, other small edits ([#1770](https://github.com/contentauth/c2pa-rs/pull/1770))

## [0.26.17](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.16...c2patool-v0.26.17)
_22 January 2026_

## [0.26.16](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.15...c2patool-v0.26.16)
_21 January 2026_

## [0.26.15](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.14...c2patool-v0.26.15)
_16 January 2026_

## [0.26.14](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.13...c2patool-v0.26.14)
_16 January 2026_

## [0.26.13](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.12...c2patool-v0.26.13)
_15 January 2026_

## [0.26.12](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.11...c2patool-v0.26.12)
_15 January 2026_

### Fixed

* Verify after sign not executing ([#1638](https://github.com/contentauth/c2pa-rs/pull/1638))

## [0.26.11](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.10...c2patool-v0.26.11)
_14 January 2026_

### Updated dependencies

* Bump toml from 0.8.23 to 0.9.10+spec-1.1.0 ([#1713](https://github.com/contentauth/c2pa-rs/pull/1713))
* Bump etcetera from 0.10.0 to 0.11.0 ([#1712](https://github.com/contentauth/c2pa-rs/pull/1712))
* Bump env_logger from 0.10.2 to 0.11.8 ([#1711](https://github.com/contentauth/c2pa-rs/pull/1711))
* Bump mockall from 0.13.1 to 0.14.0 ([#1708](https://github.com/contentauth/c2pa-rs/pull/1708))

## [0.26.10](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.9...c2patool-v0.26.10)
_07 January 2026_

## [0.26.9](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.8...c2patool-v0.26.9)
_22 December 2025_

## [0.26.8](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.7...c2patool-v0.26.8)
_19 December 2025_

## [0.26.7](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.6...c2patool-v0.26.7)
_04 December 2025_

## [0.26.6](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.5...c2patool-v0.26.6)
_04 December 2025_

### Added

* Support JSON settings in `c2patool` ([#1635](https://github.com/contentauth/c2pa-rs/pull/1635))

### Documented

* Add doc for CLI settings, misc copy edits ([#1636](https://github.com/contentauth/c2pa-rs/pull/1636))

## [0.26.5](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.4...c2patool-v0.26.5)
_17 November 2025_

## [0.26.4](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.3...c2patool-v0.26.4)
_17 November 2025_

## [0.26.3](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.2...c2patool-v0.26.3)
_13 November 2025_

## [0.26.2](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.1...c2patool-v0.26.2)
_12 November 2025_

### Fixed

* Use Digitalsourcetype with Builder intents ([#1586](https://github.com/contentauth/c2pa-rs/pull/1586))

## [0.26.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.26.0...c2patool-v0.26.1)
_07 November 2025_

## [0.26.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.25.0...c2patool-v0.26.0)
_06 November 2025_

### Added

* Sync/async HTTP resolvers API ([#1355](https://github.com/contentauth/c2pa-rs/pull/1355))

## [0.25.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.24.0...c2patool-v0.25.0)
_04 November 2025_

### Added

* Allow reading a manifest store as a Builder to continue editing ([#1476](https://github.com/contentauth/c2pa-rs/pull/1476))

### Fixed

* Update to avoid deprecation warning for Command::cargo_bin ([#1548](https://github.com/contentauth/c2pa-rs/pull/1548))

### Other

* Revert "chore: release ([#1535](https://github.com/contentauth/c2pa-rs/pull/1535))"

## [0.24.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.23.4...c2patool-v0.24.0)
_24 October 2025_

### Added

* Add settings structs to the public API ([#1447](https://github.com/contentauth/c2pa-rs/pull/1447))

### Documented

* Change relative to absolute URLs ([#1418](https://github.com/contentauth/c2pa-rs/pull/1418))

### Fixed

* Timestamp grace for legacy manifests ([#1502](https://github.com/contentauth/c2pa-rs/pull/1502))
* Turn on trust by default ([#1483](https://github.com/contentauth/c2pa-rs/pull/1483))

### Other

* Update httpmock to 0.8.0 ([#1472](https://github.com/contentauth/c2pa-rs/pull/1472))

### Updated dependencies

* Bump pem from 3.0.5 to 3.0.6 ([#1511](https://github.com/contentauth/c2pa-rs/pull/1511))
* Bump clap from 4.5.47 to 4.5.50 ([#1506](https://github.com/contentauth/c2pa-rs/pull/1506))
* Bump httpmock from 0.8.1 to 0.8.2 ([#1504](https://github.com/contentauth/c2pa-rs/pull/1504))

## [0.23.4](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.23.3...c2patool-v0.23.4)
_02 October 2025_

## [0.23.3](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.23.2...c2patool-v0.23.3)
_30 September 2025_

### Fixed

* AllActionsIncluded defaults to None ([#1459](https://github.com/contentauth/c2pa-rs/pull/1459))

## [0.23.2](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.23.1...c2patool-v0.23.2)
_24 September 2025_

### Fixed

* We lost the ability to read the deprecated instanceId actions parameters field. ([#1443](https://github.com/contentauth/c2pa-rs/pull/1443))

## [0.23.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.23.0...c2patool-v0.23.1)
_23 September 2025_

### Documented

* Document `--external-manifest` c2patool argument ([#1435](https://github.com/contentauth/c2pa-rs/pull/1435))

## [0.23.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.22.1...c2patool-v0.23.0)
_19 September 2025_

### Added

* Allow specifying external binary manifest to `c2patool` ([#1428](https://github.com/contentauth/c2pa-rs/pull/1428))

## [0.22.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.22.0...c2patool-v0.22.1)
_15 September 2025_

## [0.22.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.21.0...c2patool-v0.22.0)
_10 September 2025_

### Added

* Remove the v1_api feature and all associated code ([#1387](https://github.com/contentauth/c2pa-rs/pull/1387))

## [0.21.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.20.4...c2patool-v0.21.0)
_06 September 2025_

### Added

* Implement CAWG X.509 signing via settings ([#1388](https://github.com/contentauth/c2pa-rs/pull/1388))

## [0.20.4](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.20.3...c2patool-v0.20.4)
_03 September 2025_

## [0.20.3](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.20.2...c2patool-v0.20.3)
_27 August 2025_

## [0.20.2](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.20.1...c2patool-v0.20.2)
_26 August 2025_

## [0.20.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.20.0...c2patool-v0.20.1)
_15 August 2025_
# Changelog

All changes to C2PA Tool are documented in this file.

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html), except that – as is typical in the Rust community – the minimum supported Rust version may be increased without a major version increase.

Since version 0.10.0, the format of this changelog is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [0.20.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.19.1...c2patool-v0.20.0)
_14 August 2025_

### Added

* Add option for configuring trust when validating identity assertions (CAI-7980) ([#1239](https://github.com/contentauth/c2pa-rs/pull/1239))
* V2 Claims are now generated by default ([#1266](https://github.com/contentauth/c2pa-rs/pull/1266))
* Expand settings API ([#1192](https://github.com/contentauth/c2pa-rs/pull/1192))

### Fixed

* Same file sign for c2patool ([#1220](https://github.com/contentauth/c2pa-rs/pull/1220))

## [0.19.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.19.0...c2patool-v0.19.1)
_18 July 2025_

### Fixed

* Clippy warnings for Rust 1.88 ([#1204](https://github.com/contentauth/c2pa-rs/pull/1204))
* Fix  c2patool --info command. ([#1190](https://github.com/contentauth/c2pa-rs/pull/1190))

## [0.19.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.18.0...c2patool-v0.19.0)
_17 June 2025_

### Added

* Update Validation for 2.2 spec compliance ([#1144](https://github.com/contentauth/c2pa-rs/pull/1144))

### Documented

* Doc cleanup ([#1143](https://github.com/contentauth/c2pa-rs/pull/1143))

## [0.18.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.17.0...c2patool-v0.18.0)
_27 May 2025_

### Added

* Make OpenSSL a default feature ([#1118](https://github.com/contentauth/c2pa-rs/pull/1118))

### Fixed

* Remove use of workspace versioning for the moment ([#1136](https://github.com/contentauth/c2pa-rs/pull/1136))
* Add CAWG support for fragmented BMFF ([#1114](https://github.com/contentauth/c2pa-rs/pull/1114))

### Other

* Remove unreleased changes to c2patool
* Integrates prebuilt library release workflow ([#1126](https://github.com/contentauth/c2pa-rs/pull/1126))

## [0.17.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.16.5...c2patool-v0.17.0)
_16 May 2025_

### Added

* [**breaking**] Merge CAWG identity SDK into main C2PA crate ([#1089](https://github.com/contentauth/c2pa-rs/pull/1089))

### Documented

* Replace old c2patool release notes with CHANGELOG ([#1063](https://github.com/contentauth/c2pa-rs/pull/1063))

## [0.16.6](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.16.5...c2patool-v0.16.6)
_14 May 2025_

### Documented

* Replace old c2patool release notes with CHANGELOG ([#1063](https://github.com/contentauth/c2pa-rs/pull/1063))

## [0.16.5](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.16.4...c2patool-v0.16.5)
_25 April 2025_

### Fixed

* Enable post_validate_async for WASI ([#1052](https://github.com/contentauth/c2pa-rs/pull/1052))

## [0.16.4](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.16.3...c2patool-v0.16.4)
_16 April 2025_

### Documented

* Remove instructions to install c2patool using binstall ([#1038](https://github.com/contentauth/c2pa-rs/pull/1038))

### Fixed

* Dynamic assertions should be gathered assertions ([#1005](https://github.com/contentauth/c2pa-rs/pull/1005))

## [0.16.3](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.16.2...c2patool-v0.16.3)
_07 April 2025_

### Fixed

* Adjust dependencies to avoid security warnings and yanked versions ([#1031](https://github.com/contentauth/c2pa-rs/pull/1031))

## [0.16.2](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.16.1...c2patool-v0.16.2)
_04 April 2025_

### Fixed

* Update openssl to address a recently-announced vulnerability ([#1024](https://github.com/contentauth/c2pa-rs/pull/1024))

## [0.16.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.16.0...c2patool-v0.16.1)
_26 March 2025_

* Update to latest c2pa-crypto crate

## [0.15.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.14.0...c2patool-v0.15.0)
_18 March 2025_

### Added

* Adds `reader.post_validate` method for CAWG validation support (#976)
* Add WASI to c2patool (#945)

### Fixed

* Remove circular dependency between C2PA and CAWG crates (#982)

### Updated dependencies

* Bump env_logger from 0.11.6 to 0.11.7 (#963)

## [0.13.3](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.13.1...c2patool-v0.13.3)
_11 February 2025_

### Fixed

* Trigger a release of c2patool to pick up latest c2pa-rs changes

## [0.13.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.13.0...c2patool-v0.13.1)
_31 January 2025_

### Fixed

* Trigger a release of c2patool to pick up latest c2pa-rs changes (#895)

## [0.13.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.12.0...c2patool-v0.13.0)
_29 January 2025_

### Added

* Claim v2 (#707)

## [0.12.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.11.1...c2patool-v0.12.0)
_22 January 2025_

### Added

* Change the definition of `Signer.raw_signer()` to return an `Option` defaulting to `None` (#869)

## [0.11.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.11.0...c2patool-v0.11.1)
_18 January 2025_

### Fixed

* Upload a distinct SBOM per platform (#856)

## [0.11.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.10.2...c2patool-v0.11.0)
_16 January 2025_

### Added

* Move COSE signing into `c2pa_crypto` crate (#807)

### Documented

* Post move cleanup (#778)

### Fixed

* Fix: Obscure glob error message for missing files

## [0.10.2](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.10.1...c2patool-v0.10.2)
_12 December 2024_

### Fixed

* No-op change to trigger new c2patool build
* Update makefile for c2patool's new location in c2pa-rs workspace

## [0.10.1](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.10.0...c2patool-v0.10.1)
_12 December 2024_

### Fixed

* No-op change to trigger new c2patool release

## [0.10.0](https://github.com/contentauth/c2pa-rs/compare/c2patool-v0.9.12...c2patool-v0.10.0)
_12 December 2024_

### Added

* Updates c2patool to use only the new Builder/Reader API (contentauth/c2patool#297)

### Documented

* Update Contributing guide, misc minor edits (contentauth/c2patool#296)

### Fixed

* Compile `c2pa-crypto` with `cargo check` (#768)

### Other

* Move c2patool source code into c2pa-rs repo (#723)
* Move profile settings to workspace Cargo.toml
* Enlarged description of c2pa command-line behavior (contentauth/c2patool[#285](https://github.com/contentauth/c2pa-rs/pull/285))

## 0.9.12
_18 October 2024_

* fix: Update c2pa-rs for RegionOfInterest support. ([contentauth/c2patool#269](https://github.com/contentauth/c2patool/pull/269))
* Fix broken link that was causing os site workflow to fail ([contentauth/c2patool#266](https://github.com/contentauth/c2patool/pull/266))
* Bump codecov/codecov-action from 3 to 4 ([contentauth/c2patool#242](https://github.com/contentauth/c2patool/pull/242))
* chore: Run all CI jobs when user is dependabot[bot]
* chore: Debug CI again
* chore: Format for consistency with c2pa-rs CI workflow ([contentauth/c2patool#265](https://github.com/contentauth/c2patool/pull/265))
* chore: Don't skip CI jobs for non-pull-request events
* chore: Retry debug
* chore: Debug action context
* chore: Skip CodeCov upload for non-member PRs ([contentauth/c2patool#263](https://github.com/contentauth/c2patool/pull/263))
* Bump EmbarkStudios/cargo-deny-action from 1 to 2 ([contentauth/c2patool#245](https://github.com/contentauth/c2patool/pull/245))
* chore: Adjust conditions for running CI jobs ([contentauth/c2patool#261](https://github.com/contentauth/c2patool/pull/261))

## 0.9.11
_16 October 2024_

* Merge hardening bug fixes ([contentauth/c2patool#260](https://github.com/contentauth/c2patool/pull/260))

## 0.9.10
_07 October 2024_

* Update c2ptool to use latest c2pa-rs ([contentauth/c2patool#258](https://github.com/contentauth/c2patool/pull/258))

## 0.9.9
_17 September 2024_

* Pull in latest bug fixes ([contentauth/c2patool#237](https://github.com/contentauth/c2patool/pull/237))
* Document fragment subcommand ([contentauth/c2patool#236](https://github.com/contentauth/c2patool/pull/236))
* Switch back to using `pull_request` instead of `pull_request_target` trigger
* Bump actions/checkout from 3 to 4 ([contentauth/c2patool#243](https://github.com/contentauth/c2patool/pull/243))
* Remove no-longer-maintained clippy-check action ([contentauth/c2patool#238](https://github.com/contentauth/c2patool/pull/238))

## 0.9.8
_30 August 2024_

* Initial fragment support ([contentauth/c2patool#230](https://github.com/contentauth/c2patool/pull/230))
* Add warning about accessing a private key directly ([contentauth/c2patool#218](https://github.com/contentauth/c2patool/pull/218))

## 0.9.7
_15 August 2024_

* Update to latest c2pa SDK ([contentauth/c2patool#222](https://github.com/contentauth/c2patool/pull/222))
* Remove rust toolchain version lock ([contentauth/c2patool#221](https://github.com/contentauth/c2patool/pull/221))
* Update security guidance to link to SECURITY.md ([contentauth/c2patool#217](https://github.com/contentauth/c2patool/pull/217))

## 0.9.6
_30 July 2024_

* Pull latest c2pa-rs bug fixes into c2patool ([contentauth/c2patool#212](https://github.com/contentauth/c2patool/pull/212))
* only run tests/clippy if labeled ([contentauth/c2patool#205](https://github.com/contentauth/c2patool/pull/205))
* Bump env_logger from 0.10.2 to 0.11.4 ([contentauth/c2patool#204](https://github.com/contentauth/c2patool/pull/204))
* Updates cargo packages and cargo.deny file. ([contentauth/c2patool#200](https://github.com/contentauth/c2patool/pull/200))

## 0.9.5
_18 July 2024_

* Update to lastest c2pa-rs ([contentauth/c2patool#197](https://github.com/contentauth/c2patool/pull/197))
* added security.md ([contentauth/c2patool#196](https://github.com/contentauth/c2patool/pull/196))

## 0.9.4
_25 June 2024_

* Update c2patool ([contentauth/c2patool#190](https://github.com/contentauth/c2patool/pull/190))
* Match c2pa-rs minimum toolchain version and test in CI ([contentauth/c2patool#188](https://github.com/contentauth/c2patool/pull/188))
* Document how to specify an icon ([contentauth/c2patool#182](https://github.com/contentauth/c2patool/pull/182))

## 0.9.3
_29 May 2024_

* Remove binary modules ([contentauth/c2patool#179](https://github.com/contentauth/c2patool/pull/179))

## 0.9.2
_24 May 2024_

* Remove integration tests for now due to extraneous binaries ([contentauth/c2patool#178](https://github.com/contentauth/c2patool/pull/178))

## 0.9.1
_22 May 2024_

* Add better support for cargo-binstall ([contentauth/c2patool#177](https://github.com/contentauth/c2patool/pull/177))

## 0.9.0
_07 May 2024_

* Integrate with c2pa-rs 0.32.0, various test case fixes. ([contentauth/c2patool#175](https://github.com/contentauth/c2patool/pull/175))
* Add HTTP source option for trust config ([contentauth/c2patool#174](https://github.com/contentauth/c2patool/pull/174))

## 0.8.2
_28 March 2024_

* fixed c2patool asset name ([contentauth/c2patool#171](https://github.com/contentauth/c2patool/pull/171))

## 0.8.1
_25 March 2024_

* use c2pa-rs 0.31.1 for actions.changes support ([contentauth/c2patool#170](https://github.com/contentauth/c2patool/pull/170))

## 0.8.0
_20 March 2024_

* allow clients to sign with a process outside of c2patool ([contentauth/c2patool#169](https://github.com/contentauth/c2patool/pull/169))
* Add trust and verification options to c2pa_tool ([contentauth/c2patool#168](https://github.com/contentauth/c2patool/pull/168))
* adds version to c2patool artifact names ([contentauth/c2patool#158](https://github.com/contentauth/c2patool/pull/158))

## 0.7.0
_22 November 2023_

* updates to c2pa-rs v0.28.2 ([contentauth/c2patool#153](https://github.com/contentauth/c2patool/pull/153))
* Update to c2pa-rs 0.28.1

## 0.6.2
_05 October 2023_

* update to c2pa 0.27.1 ([contentauth/c2patool#146](https://github.com/contentauth/c2patool/pull/146))
* Merge branch 'main' of https://github.com/contentauth/c2patool
* Add Do not train example
* Upgrade to c2pa-rs 0.26.0 ([contentauth/c2patool#143](https://github.com/contentauth/c2patool/pull/143))
* Fix issue with docusaurus styling and fix broken links ([contentauth/c2patool#138](https://github.com/contentauth/c2patool/pull/138))
* Updates to c2pa-rs 0.25.1 ([contentauth/c2patool#128](https://github.com/contentauth/c2patool/pull/128))
* Fix windows release ([contentauth/c2patool#132](https://github.com/contentauth/c2patool/pull/132))

## 0.6.1
_24 July 2023_

* use compress-archive instead of tar ([contentauth/c2patool#130](https://github.com/contentauth/c2patool/pull/130))

## 0.6.0
_22 June 2023_

* update to c2pa-rs 0.24.0 ([contentauth/c2patool#127](https://github.com/contentauth/c2patool/pull/127))

## 0.5.4
_13 June 2023_

* integrate c2pa 23.0 bump version ([contentauth/c2patool#126](https://github.com/contentauth/c2patool/pull/126))
* Merge branch 'main' of https://github.com/contentauth/c2patool
* c2pa-rs 23.0 + updated test
* Update README.md ([contentauth/c2patool#124](https://github.com/contentauth/c2patool/pull/124))

## 0.5.3
_04 May 2023_

* Parent Ingredient JSON ([contentauth/c2patool#123](https://github.com/contentauth/c2patool/pull/123))

## 0.5.2
_19 April 2023_

* Ingredient thumbnails, extension cleanup, toolkit update ([contentauth/c2patool#120](https://github.com/contentauth/c2patool/pull/120))

## 0.5.1
_10 April 2023_

* Update README.md ([contentauth/c2patool#118](https://github.com/contentauth/c2patool/pull/118))
* Update expired sample certs ([contentauth/c2patool#113](https://github.com/contentauth/c2patool/pull/113))

## 0.5.0
_28 March 2023_

* New ingredient support and c2pa file formats ([contentauth/c2patool#111](https://github.com/contentauth/c2patool/pull/111))
* Leverage new Manifest & Ingredient, add Ingredient creation. ([contentauth/c2patool#107](https://github.com/contentauth/c2patool/pull/107))

## 0.4.0
_01 March 2023_

* Add --certs and --tree options ([contentauth/c2patool#106](https://github.com/contentauth/c2patool/pull/106))
* update to cp2pa 0.17.0 ([contentauth/c2patool#105](https://github.com/contentauth/c2patool/pull/105))
* Update for Clippy in Rust 1.67 ([contentauth/c2patool#101](https://github.com/contentauth/c2patool/pull/101))

## 0.3.9
_06 December 2022_

* update to c2pa-rs 0.16.0
* allows clients to output manifest report to specified directory ([contentauth/c2patool#91](https://github.com/contentauth/c2patool/pull/91))

## 0.3.8
_09 November 2022_

* Bump c2pa from 0.13.2 to 0.15.0 ([contentauth/c2patool#87](https://github.com/contentauth/c2patool/pull/87))
* Build infrastructure improvements ([contentauth/c2patool#85](https://github.com/contentauth/c2patool/pull/85))
* Fix new Clippy warning in Rust 1.65 ([contentauth/c2patool#84](https://github.com/contentauth/c2patool/pull/84))
* Readme updates ([contentauth/c2patool#62](https://github.com/contentauth/c2patool/pull/62))

## 0.3.7
_22 September 2022_

* Treat a source asset with a manifest store as a default parent ([contentauth/c2patool#76](https://github.com/contentauth/c2patool/pull/76))
* Fetch remote manifests for --info ([contentauth/c2patool#75](https://github.com/contentauth/c2patool/pull/75))

## 0.3.6
_16 September 2022_

* Update Cargo.lock when publishing crate ([contentauth/c2patool#71](https://github.com/contentauth/c2patool/pull/71))
* [IGNORE] update readme --info ([contentauth/c2patool#70](https://github.com/contentauth/c2patool/pull/70))
* Update Cargo.lock to 0.3.5

## 0.3.5
_15 September 2022_

* Upgrade cpufeatures to non-yanked version ([contentauth/c2patool#68](https://github.com/contentauth/c2patool/pull/68))
* Add --info option  ([contentauth/c2patool#65](https://github.com/contentauth/c2patool/pull/65))
* Updated publish workflow to upload binaries to GitHub ([contentauth/c2patool#58](https://github.com/contentauth/c2patool/pull/58))
* Fix Make release script & update readme ([contentauth/c2patool#55](https://github.com/contentauth/c2patool/pull/55))
* (Some version history omitted as we worked on some release process issues)

## 0.3.0
_18 August 2022_

* Rework c2patool parameters ([contentauth/c2patool#53](https://github.com/contentauth/c2patool/pull/53))
* Update to 0.11.0 c2pa-rs ([contentauth/c2patool#38](https://github.com/contentauth/c2patool/pull/38))
* Remove Homebrew, Git installation methods, and add "update" wording ([contentauth/c2patool#33](https://github.com/contentauth/c2patool/pull/33))

## 0.2.1
_29 June 2022_

* Add BMFF support for video & etc ([contentauth/c2patool#25](https://github.com/contentauth/c2patool/pull/25))

## 0.2.0
_28 June 2022_

* Upgrade to c2pa Rust SDK version 0.6.0 ([contentauth/c2patool#24](https://github.com/contentauth/c2patool/pull/24))
* Fix an error in the README documentation ([contentauth/c2patool#23](https://github.com/contentauth/c2patool/pull/23))
* Display help if there are no arguments on the command line ([contentauth/c2patool#21](https://github.com/contentauth/c2patool/pull/21))
* Bump anyhow from 1.0.57 to 1.0.58 ([contentauth/c2patool#17](https://github.com/contentauth/c2patool/pull/17))
* Updates examples to use ta_url instead of ta ([contentauth/c2patool#15](https://github.com/contentauth/c2patool/pull/15))

## 0.1.3
_17 June 2022_

* Update to latest c2pa Rust SDK ([contentauth/c2patool#12](https://github.com/contentauth/c2patool/pull/12))
* Add built-in default certs to make getting started easier ([contentauth/c2patool#9](https://github.com/contentauth/c2patool/pull/9))

## 0.1.2
_10 June 2022_

* Update crate's description field

## 0.1.1
_10 June 2022_

* Initial public release
